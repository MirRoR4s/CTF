package main

import "embed"

//go:embed *
var Static embed.FS
